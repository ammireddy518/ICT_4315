package com.parking.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.parking.Address;
import com.parking.Car;
import com.parking.CarType;
import com.parking.Customer;
import com.parking.ParkingOffice;
import com.parking.ParkingService;

public class ParkingServiceTest {
	ParkingService service;

	@Before
	public void setup() {
		ParkingOffice office = new ParkingOffice();
		service = new ParkingService(office);
	}
	
	@Test
	public void testPerformCommand() throws Exception {
		Address address = new Address("address1", "address2", "city", "state", "1234");
		Customer customer = new Customer("name", address, "1234567890");
		String[] customerProps = {"name=" + customer.getName(), "streetAddress1=" + customer.getAddress().getStreetAddress1(), "streetAddress2=" + customer.getAddress().getStreetAddress2(), "city=" + customer.getAddress().getCity(), "state=" + customer.getAddress().getState(), "zipCode=" + customer.getAddress().getZipCode(), "phone="+ customer.getPhoneNumber()};
		String customerId = service.performCommand("CUSTOMER", customerProps);
		customer.setCustomerId(customerId);
		Assert.assertEquals("Customer 1", customerId);
		
		Car car = new Car("CAR123", CarType.COMPACT, customer.getCustomerId());
		String[] carProps = {"license=" + car.getLicense(), "customerId=" + car.getCustomerId(), "carType=" + car.getType().toString()};
		String permitId = service.performCommand("CAR", carProps);
		Assert.assertEquals("Permit 1", permitId);
	}
}
