package com.parking;

import org.apache.commons.lang3.StringUtils;

public class Address {

	private String streetAddress1;

	private String streetAddress2;

	private String city;

	private String state;

	private String zipCode;

	public Address(String streetAddress1, String streetAddress2, String city, String state, String zipCode)
			throws Exception {
		super();
		if (StringUtils.isAnyBlank(streetAddress1, city, state, zipCode)) {
			String msg = "Please enter valid ";
			if (StringUtils.isBlank(streetAddress1)) {
				msg += "streetAddress1 ";
			}
			if (StringUtils.isBlank(city)) {
				msg += "city ";
			}
			if (StringUtils.isBlank(state)) {
				msg += "state ";
			}
			if (StringUtils.isBlank(zipCode)) {
				msg +="zipCode ";
			}
			throw new Exception(msg);
		} else {
			this.streetAddress1 = streetAddress1;
			this.streetAddress2 = streetAddress2;
			this.city = city;
			this.state = state;
			this.zipCode = zipCode;
		}
	}

	public String getStreetAddress1() {
		return streetAddress1;
	}

	public String getStreetAddress2() {
		return streetAddress2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getAddressInfo() {
		return "Address [streetAddress1=" + streetAddress1 + ", streetAddress2=" + streetAddress2 + ", city=" + city
				+ ", state=" + state + ", zipCode=" + zipCode + "]";
	}
}
