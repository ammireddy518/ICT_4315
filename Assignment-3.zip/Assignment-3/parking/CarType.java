package com.parking;

public enum CarType {
	COMPACT,
	SUV
}
