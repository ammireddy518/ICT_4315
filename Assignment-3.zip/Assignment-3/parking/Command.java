package com.parking;

public interface Command {

	public String getCommandName();
	
	public String getDisplayName();
	
	public String execute(Properties params);
	
	public boolean checkParameters(Properties params);
}
