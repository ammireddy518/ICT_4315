package com.parking;

public interface IPricingStrategy {
	
	public double parkingCharge(double amount); 

}
