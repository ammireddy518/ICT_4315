package com.parking;
/**
 * If the lot is not frequently used by everyone, then the prices are reduced a little
 * so that everyone will get used to park the cars in this lot.
 */
public class LotUsageBasedPricingStrategy implements IPricingStrategy{

	@Override
	public double parkingCharge(double amount) {
		// A 10% discount is given if the lot is not frequently used.
		return amount*0.9;
	}

}
