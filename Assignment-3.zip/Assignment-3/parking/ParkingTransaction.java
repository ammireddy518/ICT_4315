package com.parking;

import java.util.Calendar;

public class ParkingTransaction {

	private Calendar transactionDate;
	private ParkingPermit permit;
	private ParkingLot lot;
	private Money feeCharged;

	public Calendar getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Calendar transactionDate) {
		this.transactionDate = transactionDate;
	}

	public ParkingPermit getPermit() {
		return permit;
	}

	public void setPermit(ParkingPermit permit) {
		this.permit = permit;
	}

	public ParkingLot getLot() {
		return lot;
	}

	public void setLot(ParkingLot lot) {
		this.lot = lot;
	}

	public Money getFeeCharged() {
		return feeCharged;
	}

	public void setFeeCharged(Money feeCharged) {
		this.feeCharged = feeCharged;
	}

}
