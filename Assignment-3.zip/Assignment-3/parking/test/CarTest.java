package com.parking.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.parking.Address;
import com.parking.Car;
import com.parking.CarType;
import com.parking.Customer;
import com.parking.ParkingOffice;
import com.parking.ParkingService;


public class CarTest {
	
	private Customer customer;
	
	private ParkingOffice office = new ParkingOffice();
	
	private Address add;
	
	@Before
	public void setup() throws Exception {
		ParkingService service = new ParkingService(office);
		add = new Address("address1", "address2", "city", "state", "zipcode");
		customer = new Customer("customerName", add, "1234567890");
		office.register(customer);
		
	}
	
	@Test
	public void testCar() throws Exception {
		Car car = new Car("CAR566", CarType.COMPACT, customer.getCustomerId());
		office.register(customer, car);
		Assert.assertEquals("Car [permit=Permit 1, license=CAR566, type=COMPACT, customerId=Customer 1]", car.toString());
	}
	
	@Test
	public void testInvalid() {
		try {
			//invalid license
			Car car = new Car("", CarType.COMPACT, customer.getCustomerId());
		} catch(Exception ex) {
			Assert.assertEquals("Please enter valid license ", ex.getMessage());
		}
		try {
			//invalid carType
			Car car = new Car("CAR566", null, customer.getCustomerId());
		} catch(Exception ex) {
			Assert.assertEquals("Please enter valid CarType ", ex.getMessage());
		}
		try {
			//invalid customerid
			Car car = new Car("CAR566", CarType.COMPACT, "");
		} catch(Exception ex) {
			Assert.assertEquals("Please enter valid customerId ", ex.getMessage());
		}
		try {
			//invalid license, cartype and customerId
			Car car = new Car("", null, "");
		} catch(Exception ex) {
			Assert.assertEquals("Please enter valid customerId license CarType ", ex.getMessage());
		}
	}

}
