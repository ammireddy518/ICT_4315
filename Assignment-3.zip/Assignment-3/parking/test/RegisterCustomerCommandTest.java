package com.parking.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.parking.ParkingOffice;
import com.parking.Properties;
import com.parking.RegisterCustomerCommand;


public class RegisterCustomerCommandTest {
	
	private RegisterCustomerCommand command = new RegisterCustomerCommand();

	@Before
	public void setup() {
		ParkingOffice office = new ParkingOffice();
		command.createParkingOffice(office);
		
	}
	
	@Test
	public void testExecuteParams() {
		Properties props = new Properties();
		props.setName("Name");
		props.setStreetAddress1("Address1");
		props.setCity("city");
		props.setState("state");
		props.setZipCode("1234");
		props.setPhoneNumber("1234567890");
		
		Assert.assertTrue(command.checkParameters(props));
		String customerId = command.execute(props);
		Assert.assertEquals("Customer 1", customerId);
		
		//If any of the required prop is invalid, the customer Id is returned as null
		props.setName(null);
		Assert.assertFalse(command.checkParameters(props));
		customerId = command.execute(props);
		Assert.assertNull(customerId);	
	}
}
