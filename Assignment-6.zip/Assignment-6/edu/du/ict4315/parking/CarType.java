package edu.du.ict4315.parking;

public enum CarType {
	COMPACT,
	SUV
}
