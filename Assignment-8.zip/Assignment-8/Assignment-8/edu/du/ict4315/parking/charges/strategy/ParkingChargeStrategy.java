package edu.du.ict4315.parking.charges.strategy;

public interface ParkingChargeStrategy {
	
	public double parkingCharge(double amount); 
	
}
