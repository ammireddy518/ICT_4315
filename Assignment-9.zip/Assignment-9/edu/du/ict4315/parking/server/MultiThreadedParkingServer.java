package edu.du.ict4315.parking.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import edu.du.ict4315.parking.client.ClientHandler;

public class MultiThreadedParkingServer {

	private static final int PORT = 12345;
	private ParkingServer parkingServer;

	public MultiThreadedParkingServer() {
		parkingServer = new ParkingServer();
	}

	public void start() {
		try (ServerSocket serverSocket = new ServerSocket(PORT)) {
			System.out.println("Server is listening on port " + PORT);
			while (true) {
				Socket clientSocket = serverSocket.accept();
				System.out.println("New client connected");
				ClientHandler clientHandler = new ClientHandler(clientSocket, parkingServer);
				Thread thread = new Thread(clientHandler);
				thread.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		MultiThreadedParkingServer server = new MultiThreadedParkingServer();
		server.start();
	}
}
