package edu.du.ict4315.parking.test;

import java.time.Duration;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import edu.du.ict4315.parking.Address;
import edu.du.ict4315.parking.Car;
import edu.du.ict4315.parking.CarType;
import edu.du.ict4315.parking.Customer;
import edu.du.ict4315.parking.Money;
import edu.du.ict4315.parking.ParkingLot;
import edu.du.ict4315.parking.ParkingLotEntryExit;
import edu.du.ict4315.parking.ParkingOffice;
import edu.du.ict4315.parking.ParkingService;

public class ApplicationTest {
	
	public ParkingOffice office;
	
	@Before
	public void setup() {
		office = new ParkingOffice();
		office.setName("Office1");
		office.setAddress("Address 1");
		ParkingService service = new ParkingService(office);
	}

	@Test
	public void testSuccess() throws Exception {
		// Create an ParkingLot object
		ParkingLot lot = new ParkingLot("lot1", "address1", 50);
		Assert.assertNotNull(lot);
		
		office.addLot(lot);

		// Create an address object
		Address address = new Address("address1", "address2", "city", "state", "zipcode");
		Assert.assertNotNull(address);

		// Create a Customer object
		Customer customer = new Customer("customerName", address, "1234567890");
		customer.setCustomerId("Customer 1");
		Assert.assertNotNull(customer);

		// Register a car
		Car car = customer.register("CAR789", CarType.COMPACT);
		Assert.assertNotNull(car);
		office.register(customer, car);
		// Car entrying a park lot
		lot.entry(car);
		Assert.assertEquals(lot.getLotId(), car.getLotId());
		Assert.assertEquals(Integer.valueOf(49), lot.getCapacity());

	}

	@Test
	public void testWithParkingOffice() throws Exception {
		// Create an ParkingLot object
		ParkingLotEntryExit lot = new ParkingLotEntryExit("lot1", "address1", 50);
		Assert.assertNotNull(lot);

		ParkingLot lot2 = new ParkingLot("lot2", "address2", 50);
		Assert.assertNotNull(lot2);

		// Create an address object
		Address address = new Address("address1", "address2", "city", "state", "zipcode");
		Assert.assertNotNull(address);

		Customer cust = office.register("customer 1", address, "123456789");
		Assert.assertNotNull(cust);

		Car car = office.register(cust, "CAR123", CarType.COMPACT);
		Assert.assertNotNull(car);
		
		office.addLot(lot);
		office.addLot(lot2);
		office.register(cust, car);
		lot.entry(car);
		Assert.assertEquals(lot.getLotId(), car.getLotId());
		Assert.assertEquals(Integer.valueOf(49), lot.getCapacity());
		
		lot.exit(car);
		Assert.assertEquals(null, car.getLotId());
		Assert.assertEquals(Integer.valueOf(50), lot.getCapacity());
		
		Money money = office.monthlyBill(cust.getCustomerId());
		Assert.assertEquals(Duration.between(car.getEntryTime(), car.getExitTime()).getSeconds(), money.getCents());
	}
}
