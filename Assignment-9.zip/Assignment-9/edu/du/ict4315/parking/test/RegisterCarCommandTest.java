package edu.du.ict4315.parking.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import edu.du.ict4315.parking.ParkingOffice;
import edu.du.ict4315.parking.Properties;
import edu.du.ict4315.parking.RegisterCarCommand;

public class RegisterCarCommandTest {

	
	private RegisterCarCommand command = new RegisterCarCommand();

	@Before
	public void setup() {
		ParkingOffice office = new ParkingOffice();
		command.createParkingOffice(office);
		
	}
	
	@Test
	public void testExecuteParams() {
		Properties props = new Properties();
		props.setCustomerId("CustomerId");
		props.setLicense("ABC123");
		props.setCarType("COMPACT");
		
		Assert.assertTrue(command.checkParameters(props));
		String permitId = command.execute(props);
		Assert.assertEquals("Permit 1", permitId);
		
		//If any of the required prop is invalid, the customer Id is returned as null
		props.setCustomerId(null);
		Assert.assertFalse(command.checkParameters(props));
		permitId = command.execute(props);
		Assert.assertNull(permitId);	
	}

}
